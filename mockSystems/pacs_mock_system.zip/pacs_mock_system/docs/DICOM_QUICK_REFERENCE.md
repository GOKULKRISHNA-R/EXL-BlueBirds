# DICOM / Orthanc quick reference

## DICOM hierarchy
Patient → Study → Series → Instance.

- Patient: demographics and PatientID.
- Study: imaging examination, identified by StudyInstanceUID.
- Series: acquisition grouping, identified by SeriesInstanceUID.
- Instance: individual DICOM object, identified by SOPInstanceUID.

## Orthanc REST API
- `GET /system`
- `GET /plugins`
- `GET /studies`
- `GET /studies/{orthanc-study-id}`
- `GET /studies/{orthanc-study-id}/series`
- `GET /series/{orthanc-series-id}/instances`
- `GET /instances/{orthanc-instance-id}/tags`
- `POST /instances`

Orthanc internal IDs are not DICOM UIDs.

## DICOMweb
- QIDO-RS: search studies/series/instances
- WADO-RS: retrieve DICOM objects/metadata/frames
- STOW-RS: store DICOM instances

Default Orthanc DICOMweb root: `/dicom-web/`.
