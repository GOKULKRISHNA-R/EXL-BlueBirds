# PACS Mock System — Orthanc DICOM Server

Standalone synthetic Picture Archiving and Communication System (PACS) for the EXL healthcare integration hackathon.

> Use synthetic or properly de-identified DICOM only. Do not upload real patient scans or identifiable clinical data. This is a hackathon mock, not a validated clinical PACS.

## 1. What this system provides

- Orthanc DICOM server running in Docker.
- DICOM network endpoint on TCP 4242 (AE Title `EXLPACS`).
- Orthanc REST API for studies, series, instances and metadata.
- DICOMweb plugin enabled for QIDO-RS, WADO-RS and STOW-RS.
- Persistent storage through a Docker volume.
- PACS-specific patient IDs and DICOM study identifiers.

DICOM hierarchy: Patient → Study → Series → Instance. Orthanc internal IDs are different from DICOM UIDs.

## 2. Start

```powershell
Copy-Item .env.example .env
docker compose up -d
docker compose ps
docker logs pacs-mock-orthanc
```

Endpoints:
- Orthanc Explorer 2: http://localhost:8042/ui/app/
- REST API base: http://localhost:8042
- DICOMweb root: http://localhost:8042/dicom-web/
- DICOM AE Title: `EXLPACS`
- DICOM host/port: `localhost:4242`

Login:
- Username: `pacs_user`
- Password: value of `ORTHANC_PASSWORD` in `.env`

The Compose file pins Orthanc Team image version `26.11.0` for reproducibility and explicitly enables DICOMweb. See the official Orthanc Docker documentation for image configuration and plugin settings: https://orthanc.uclouvain.be/book/users/docker-orthancteam.html

## 3. Validate REST access from PowerShell

```powershell
$envLines = Get-Content .env
$password = ($envLines | Where-Object { $_ -match '^ORTHANC_PASSWORD=' }) -replace '^ORTHANC_PASSWORD=', ''
$credential = "pacs_user:$password"
$encoded = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes($credential))
$headers = @{ Authorization = "Basic $encoded" }

Invoke-RestMethod -Uri "http://localhost:8042/system" -Headers $headers
```

List plugins and confirm DICOMweb:

```powershell
Invoke-RestMethod -Uri "http://localhost:8042/plugins" -Headers $headers
```

List studies:

```powershell
Invoke-RestMethod -Uri "http://localhost:8042/studies" -Headers $headers
```

A fresh server should return `[]`. This is expected until DICOM files are uploaded.

## 4. Generate synthetic DICOM files

From the project folder, install the generator dependencies:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r tools/requirements.txt
python tools/generate_sample_dicom.py
```

This creates three synthetic CT DICOM instances for the fictional PACS patient `PACS-PT-7001`, with a shared StudyInstanceUID and SeriesInstanceUID. The pixel values are artificial test patterns, not diagnostic images.

## 5. Upload a synthetic DICOM instance

```powershell
Get-ChildItem .\data\synthetic_dicom\*.dcm | ForEach-Object {
    Invoke-RestMethod `
      -Method Post `
      -Uri "http://localhost:8042/instances" `
      -Headers $headers `
      -ContentType "application/dicom" `
      -InFile $_.FullName
}
```

Expected responses contain `ID`, `ParentStudy`, `ParentSeries` and `Status` (typically `Success`).

List studies:

```powershell
$studies = Invoke-RestMethod -Uri "http://localhost:8042/studies" -Headers $headers
$studies
```

Inspect the first study:

```powershell
$studyId = $studies[0]
Invoke-RestMethod -Uri "http://localhost:8042/studies/$studyId" -Headers $headers |
    ConvertTo-Json -Depth 10
```

Inspect its DICOM tags:

```powershell
Invoke-RestMethod -Uri "http://localhost:8042/studies/$studyId/tags" -Headers $headers |
    ConvertTo-Json -Depth 10
```

## 6. Validate DICOMweb

Confirm `/plugins` contains `dicom-web`. Then try QIDO-RS:

```powershell
Invoke-WebRequest `
  -Uri "http://localhost:8042/dicom-web/studies" `
  -Headers $headers
```

After uploading the sample, this should return the study search result. DICOMweb responses use DICOM JSON and the relevant DICOMweb media types; this is separate from Orthanc's own REST JSON API.

## 7. DICOM identifiers and cross-system identity

The PACS uses `PACS-PT-7001`, not the EHR or LIS patient ID. Important DICOM attributes include:

- PatientID (0010,0020)
- IssuerOfPatientID (0010,0021)
- PatientName (0010,0010)
- PatientBirthDate (0010,0030)
- AccessionNumber (0008,0050)
- StudyInstanceUID (0020,000D)
- SeriesInstanceUID (0020,000E)
- SOPInstanceUID (0008,0018)
- Modality (0008,0060)

Do not assume PatientID is globally unique. Preserve assigning authority/issuer and reconcile identity using multiple attributes and provenance, not patient name alone.

## 8. Persistence and reset

Stop without deleting studies:

```powershell
docker compose down
```

Reset and permanently delete stored synthetic DICOM data:

```powershell
docker compose down -v
docker compose up -d
```

## 9. Scope and limitations

This is a hackathon PACS mock, not a vendor-certified clinical archive. It does not implement enterprise storage tiering, clinical audit workflows, modality worklists, disaster recovery, or production-grade authorization policies. Keep it local and use only synthetic data.
