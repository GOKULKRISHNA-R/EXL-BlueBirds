"""Generate a tiny synthetic CT DICOM series for local PACS integration testing.

All demographics and pixel data are fictional/artificial. These images are not
medical images and must never be used for diagnosis or clinical decisions.
"""
from pathlib import Path
from datetime import datetime, timedelta
import numpy as np
from pydicom import Dataset, FileDataset, FileMetaDataset
from pydicom.uid import ExplicitVRLittleEndian, CTImageStorage, generate_uid

OUT = Path(__file__).resolve().parents[1] / "data" / "synthetic_dicom"
OUT.mkdir(parents=True, exist_ok=True)

study_uid = generate_uid()
series_uid = generate_uid()
frame_uid = generate_uid()
implementation_uid = generate_uid()
now = datetime.now()

for index in range(1, 4):
    sop_uid = generate_uid()
    file_meta = FileMetaDataset()
    file_meta.MediaStorageSOPClassUID = CTImageStorage
    file_meta.MediaStorageSOPInstanceUID = sop_uid
    file_meta.TransferSyntaxUID = ExplicitVRLittleEndian
    file_meta.ImplementationClassUID = implementation_uid

    path = OUT / f"synthetic_ct_{index:03d}.dcm"
    ds = FileDataset(str(path), {}, file_meta=file_meta, preamble=b"\0" * 128)
    ds.SOPClassUID = CTImageStorage
    ds.SOPInstanceUID = sop_uid
    ds.StudyInstanceUID = study_uid
    ds.SeriesInstanceUID = series_uid
    ds.FrameOfReferenceUID = frame_uid
    ds.PatientName = "SYNTHETIC^TESTPATIENT"
    ds.PatientID = "PACS-PT-7001"
    ds.IssuerOfPatientID = "EXL-MOCK-PACS"
    ds.PatientBirthDate = "19950510"
    ds.PatientSex = "M"
    ds.AccessionNumber = "PACS-ACC-7001"
    ds.StudyID = "STUDY-7001"
    ds.StudyDescription = "Synthetic CT Test Study - Non-diagnostic"
    ds.SeriesDescription = "Artificial Pixel Pattern"
    ds.Modality = "CT"
    ds.Manufacturer = "EXL Hackathon Synthetic Generator"
    ds.StudyDate = now.strftime("%Y%m%d")
    ds.StudyTime = now.strftime("%H%M%S")
    ds.SeriesNumber = 1
    ds.InstanceNumber = index
    ds.ImageType = ["ORIGINAL", "PRIMARY", "AXIAL"]
    ds.Rows = 32
    ds.Columns = 32
    ds.SamplesPerPixel = 1
    ds.PhotometricInterpretation = "MONOCHROME2"
    ds.BitsAllocated = 16
    ds.BitsStored = 16
    ds.HighBit = 15
    ds.PixelRepresentation = 1
    ds.RescaleIntercept = -1024
    ds.RescaleSlope = 1
    ds.SliceThickness = "1.0"
    ds.ImagePositionPatient = [0.0, 0.0, float(index - 1)]
    ds.ImageOrientationPatient = [1.0, 0.0, 0.0, 0.0, 1.0, 0.0]
    ds.PixelSpacing = [1.0, 1.0]
    # Artificial gradient/checker pattern only; no anatomical content.
    y, x = np.mgrid[0:32, 0:32]
    pixels = ((x * 23 + y * 17 + index * 101) % 1800 - 900).astype("<i2")
    ds.PixelData = pixels.tobytes()
    ds.is_little_endian = True
    ds.is_implicit_VR = False
    ds.save_as(path, enforce_file_format=True)
    print(f"Created {path}")

print(f"\nGenerated {3} artificial DICOM instances in: {OUT}")
